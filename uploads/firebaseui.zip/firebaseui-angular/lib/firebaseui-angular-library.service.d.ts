import { AngularFireAuth } from '@angular/fire/auth';
import * as firebaseui from 'firebaseui';
export declare class FirebaseuiAngularLibraryService {
    firebaseUiInstance: firebaseui.auth.AuthUI;
    constructor(angularFireAuth: AngularFireAuth);
}
